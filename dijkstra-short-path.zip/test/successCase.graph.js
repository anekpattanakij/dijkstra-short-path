const assert = require('assert');
const Graph = require('../libs/graph');

describe('Pass Case', () => {
  let graph;
  beforeEach(() => {
    graph = new Graph();
  });
  it('Pass Case', () => {
    // arrange
    graph.addNode('A', new Map([['B', 2], ['C', 2]]));
    // act
    const total = graph.path('A', 'B');
    // assert
    assert.equal(total.distance, 25);
    assert.deepEqual(total.path, ['A', 'B', 'D']);
  });
});
